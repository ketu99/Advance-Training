package com.shoppingcartapplication.dao;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.shoppingcartapplication.Product;
import java.util.List;

public interface ProductDAO {
	
		public void addProduct(Product p);
		public void updateProduct(Product p);
		public List<Product> listProducts();
		public Product getProductById(int ProductID);
		public void removeProduct(int ProductID);
		
}
