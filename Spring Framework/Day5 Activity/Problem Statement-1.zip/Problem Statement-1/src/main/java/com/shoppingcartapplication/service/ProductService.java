package com.shoppingcartapplication.service;

import java.util.List;

import com.shoppingcartapplication.Product;

public interface ProductService {
	public void addProduct(Product p);
	public void updateProduct(Product p);
	public List<Product> listProducts();
	public Product getProductById(int ProductID);
	public void removeProduct(int ProductID);
}
